A Pen created at CodePen.io. You can find this one at https://codepen.io/collosic/pen/JpDfn.

 I apologize for not putting comments.  I was trying to finish this quickly, but it took me much longer than I expected.  There are probably some minor bugs in the cpu logic still.  I will try my best to iron those out when I get some time.  I have many layout and design changes to make in the future.  